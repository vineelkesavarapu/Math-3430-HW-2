import LA
import QR
import LS
print("LA.py contains a bunch of functions that perform linear algebra formulas.")
print("The fourth function in LA.py is add_matrices. It takes two matrices as the argument and return the sum.")

print("If matrix_a=[[1, 2],[3, 4]] and matrix_b=[[-1, -2],[-3, -4]], then add_matrices(matrix_a,matrix_b) will return")
matrix_a=[[1, 2],[3, 4]]
matrix_b=[[-1, -2],[-3, -4]]
print(LA.add_matrices(matrix_a,matrix_b))

print("QR.py contains a function of gram-schmidt that is stable and unstable.")
print("The first function in QR.py is unstable_gram_schmidt. It shows us the unstable gram-schmidt does not come accurate.")

print("If  Q: list = [] and R: list = [[0,0,0],[0,0,0],[0,0,0]], then unstable_gram_schmidt([[1,1,0],[1,0,1],[0,1,1]]) will return")
Q,R = QR.stable_gram_schmidt([[1,1,0],[1,0,1],[0,1,1]])
print(Q)
print(R)

print("LS.py contains a function that solves for a square solution.")
print("The first function in LS.py is solve. It solves the system Rx = d where R is an upper triangular")

print("If R = [[1,0,0],[2,1,0],[0,0,4]] and d = [1,1,1], then x = [-1,1,1/4]")
print(LS.solve([[1,0,0],[2,1,0],[0,0,4]],[1,1,1]))

print("The second function in LS.py is transpose. It transposes any matrix. For example, if A = [[1,1,1],[2,2,2],[3,3,3]] then transpose(A) is [[1,2,3],[1,2,3],[1,2,3]]")
print(LS.transpose([[1,1,1],[2,2,2],[3,3,3]]))