import LS
import LA
import QR

def test_solve():
    x1 = LS.solve([[1,0,0],[0,1,0],[0,0,1]],[1,2,3])
    x2 = LS.solve([[5,0,0],[0,2,0],[0,0,3]],[1,2,3])

    assert(x1 == [1,2,3])
    assert(x2 == [1/5,1,1])

def test_transpose():

    a1 = LS.transpose([[1,1,1],[2,2,2],[3,3,3]])
    a2 = LS.transpose([[1,0,0],[0,2,0],[0,0,3]])

    assert(a1 == [[1,2,3],[1,2,3],[1,2,3]])
    assert(a2 == [[1,0,0],[0,2,0],[0,0,3]])
    
test_solve()
test_transpose()
