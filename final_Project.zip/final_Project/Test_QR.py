import QR
import LA

from math import sqrt

#Q1,R1 = QR.unstable_gram_schmidt([[1,1,0],[1,0,1],[0,1,1]])

Qtrue1 = [[1/sqrt(2),1/sqrt(2),0],
          [1/sqrt(6),-1/sqrt(6),2/sqrt(6)],
          [-1/sqrt(3),1/sqrt(3),1/sqrt(3)]]

Qtrue2 = [[6/7,3/7,-2/7],
          [-69/175,158/175,6/35],
          [-58/175,6/175,-33/35]]


def test_stable_gram_schmidt():
    Q1,R1 = QR.stable_gram_schmidt([[1,1,0],[1,0,1],[0,1,1]])
    Q2,R2 = QR.stable_gram_schmidt([[12,6,-4],[-51,167,24],[4,-68,-41]])

    #print(Qtrue2)
    #print(Q2)

    # look at error between Q2 and Qtrue
    err1 = 0
    for i in range(len(Q1)):
        for j in range(len(Q1[0])):
            err1 += abs(Q1[i][j] - Qtrue1[i][j])

    err2 = 0
    for i in range(len(Q2)):
        for j in range(len(Q2[0])):
            err2 += abs(Q2[i][j] - Qtrue2[i][j])


    assert(err1 < 1e-10)
    assert(err2 < 1e-10)



def test_householder_QR():
    Q1,R1 = QR.householder_QR([[1,1,0],[1,0,1],[0,1,1]])
    Q2,R2 = QR.householder_QR([[12,6,-4],[-51,167,24],[4,-68,-41]])

    # look at error between Q2 and Qtrue
    err1 = 0
    for i in range(len(Q1)):
        for j in range(len(Q1[0])):
            err1 += abs(Q1[i][j] - Qtrue1[i][j])

    err2 = 0
    for i in range(len(Q2)):
        for j in range(len(Q2[0])):
            err2 += abs(Q2[i][j] - Qtrue2[i][j])


    assert(err1 < 1e-10)
    assert(err2 < 1e-10)

def test_orthonormal_vectors():
    
    v1 = QR.orthonormal_vectors([[1,0,0],[0,1,0],[0,0,1]])[0]
    v2 = QR.orthonormal_vectors([[3,0,0],[0,1,0],[0,0,2]])[0]

    assert(v1 == [[1,0,0],[0,1,0],[0,0,1]])
    assert(v2 == [[1,0,0],[0,1,0],[0,0,1]])

test_stable_gram_schmidt()
test_orthonormal_vectors()
test_householder_QR()